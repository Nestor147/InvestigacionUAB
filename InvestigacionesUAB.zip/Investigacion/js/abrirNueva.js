const enlaces = document.querySelectorAll(".enlace");

enlaces.forEach((enlace) => {
  enlace.addEventListener("click", function(event) {
    event.preventDefault();
    window.open(this.href, "_blank");
  });
});
